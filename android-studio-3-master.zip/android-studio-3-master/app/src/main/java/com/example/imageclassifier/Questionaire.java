package com.example.imageclassifier;

import android.content.Intent;
import android.content.SharedPreferences;
import android.icu.util.Output;
import android.os.Bundle;

import com.google.android.material.appbar.CollapsingToolbarLayout;
import com.google.android.material.floatingactionbutton.FloatingActionButton;
import com.google.android.material.snackbar.Snackbar;

import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;

import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.RadioButton;
import android.widget.RadioGroup;
import android.widget.Toast;

import java.util.HashMap;
import java.util.Map;

public class Questionaire extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_questionaire);

        final RadioGroup[] arr = {
                findViewById(R.id.q1),
                findViewById(R.id.q12),
                findViewById(R.id.q2),
                findViewById(R.id.q3),
                findViewById(R.id.q4),
                findViewById(R.id.q5),
                findViewById(R.id.q6),
                findViewById(R.id.q7),
                findViewById(R.id.q8),
                findViewById(R.id.q9),
                findViewById(R.id.q10),
                findViewById(R.id.q11),
                findViewById(R.id.q12),
                findViewById(R.id.q19),
                findViewById(R.id.q20),
                findViewById(R.id.q13),
                findViewById(R.id.q14),
                findViewById(R.id.q15),
                findViewById(R.id.q16),
                findViewById(R.id.q17),
        };

        Button submit = (Button) findViewById(R.id.btn_submit);
        submit.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                SharedPreferences data = getSharedPreferences("AYSI",MODE_PRIVATE);
                SharedPreferences.Editor editor = data.edit();
                String str = "";
                boolean allDone = true;
                for (int x = 0; x < 20; x++) {
                    if (x==1) {
                        EditText number = (EditText) findViewById(R.id.q21_number);
                        if (number.getText().toString().equals("") || Integer.parseInt(""+number.getText()) > 20 || Integer.parseInt(""+number.getText()) <15) {
                            Toast.makeText(getApplicationContext(),"Invalid Number for Age Question!", Toast.LENGTH_LONG).show();
                            allDone = false;
                            break;
                        } else
                            str = str + number.getText() + " ";
                        continue;
                    }

                    if (arr[x].getCheckedRadioButtonId() == -1) {
                        Toast.makeText(getApplicationContext(), "Not All Questions Were Answered!", Toast.LENGTH_LONG).show();
                        allDone = false;
                        break;
                    } else {
                        RadioButton rb = (RadioButton) findViewById(arr[x].getCheckedRadioButtonId());

                        str = str + rb.getTag() + " ";
                        Log.d("DEBUG", "" + rb.getTag(0));
                    }


                }
                EditText num = (EditText) findViewById(R.id.q18_number);
                if (num.getText().toString().equals("") || Integer.parseInt(""+num.getText()) > 93 || Integer.parseInt(""+num.getText()) <0) {
                    Toast.makeText(getApplicationContext(),"Invalid Number for number of absences question!", Toast.LENGTH_LONG).show();
                    allDone = false;
                } else
                    str = str + num.getText();
                Log.d("DEBUG", "data  >>> " + str);
                if (allDone) {
                    editor.putString("data", str);
                    editor.commit();
                    startActivity(new Intent(Questionaire.this, OutputActivity.class));
                }
            }
        });
    }

    @Override
    protected void onStart() {
        super.onStart();
        SharedPreferences prefss = getSharedPreferences("AYSI",MODE_PRIVATE);
        String str = prefss.getString("data","-1");
        if (!str.equals("-1"))
            finish();
    }


}