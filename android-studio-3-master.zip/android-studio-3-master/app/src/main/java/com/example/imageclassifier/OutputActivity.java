
package com.example.imageclassifier;

import androidx.appcompat.app.AppCompatActivity;

import android.content.SharedPreferences;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;
import org.tensorflow.lite.Interpreter;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Arrays;

public class OutputActivity extends AppCompatActivity {
    private Interpreter tflite;
    private ArrayList<String> labelList;
    private int output;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_output);
        TextView outLabels = (TextView) findViewById(R.id.tv_outputLabel);
        TextView description = (TextView) findViewById(R.id.tv_outputDescription);

        try {
            tflite = new Interpreter(Helper.loadModelFile(this.getAssets()), new Interpreter.Options());
            labelList = Helper.loadLabelList(this.getAssets());
        } catch (IOException e) {
            e.printStackTrace();
        }

        calculate();
        outLabels.setText("" + output);
        switch (output) {
            case 1:
                outLabels.setBackgroundResource(R.drawable.rounded_corners_green);
                description.setText("A Alcohol Risk Level of 1 means you have minimal risk of drinking on weekends.");
                break;
            case 2:
                outLabels.setBackgroundResource(R.drawable.rounded_corners_yellow);
                description.setText("A Alcohol Risk Level of 2 means you have a low risk of drinking on weekends.");
                break;
            case 3:
                outLabels.setBackgroundResource(R.drawable.rounded_corners_orange);
                description.setText("A Alcohol Risk Level of 3 means you have a moderate risk of drinking on weekends.");
                break;
            case 4:
                outLabels.setBackgroundResource(R.drawable.rounded_corners_lightred);
                description.setText("A Alcohol Risk Level of 4 means you have a high risk of drinking on weekends.");
                break;
            case 5:
                outLabels.setBackgroundResource(R.drawable.rounded_corners_red);
                description.setText("A Alcohol Risk Level of 5 means you have an extremely high risk of drinking on weekends.");
                break;
            default:
                outLabels.setText("?");
                description.setText("Sorry, there was an error in calculating your risk level. Restart the app and try again.");
                break;
        }

        Button goBack = (Button) findViewById(R.id.btn_goBackToStart);
        goBack.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                finish();
            }
        });

    }
    public void calculate() {
        float[][] label = new float[1][6];
        float[] data = new float[21];
        SharedPreferences prefs = getSharedPreferences("AYSI",MODE_PRIVATE);
        String str = prefs.getString("data","-1");
        String[] arr = str.split(" ");
        Log.d("debug","data >>> " + str);
        Log.d("debug","array of data >>> " + Arrays.toString(arr));
        for (int x = 0; x < 21; x++) {
            data[x] = (float) Integer.parseInt(arr[x]);
        }

        tflite.run(data, label);
        output = 0;
        for (int x = 0; x < 6; x++) {
            if (Math.round(label[0][x]) == 1) {
                output = x;
            }
        }
        Log.d("DEBUG","" + output);

    }
}