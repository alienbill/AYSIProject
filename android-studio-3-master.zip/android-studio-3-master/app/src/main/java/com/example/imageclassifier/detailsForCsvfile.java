package com.example.imageclassifier;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;

public class detailsForCsvfile extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_details_for_csvfile);

        TextView tv_details = findViewById(R.id.tv_detailsForCSV);


        String[] desc = {
                "1) SEX ([MALE:1], [FEMALE:0])",
                "2) AGE (15-20)",
                "3) ADDRESS ([URBAN:1], [RURAL:0])",
                "4) FAMILY SIZE ([LESS THAN OR EQUAL TO 3:1], [GREATER THAN 3:0])",
                "5) PARENTAL STATUS ([TOGETHER:1], [APART:0])",
                "6) MOTHER'S EDUCATION ([NONE:0], [1-4 GRADE:1], [5-9 GRADE:2], [10-12 GRADE:3], [UNIVERSITY:4])",
                "7) FATHER'S EDUCATION ([NONE:0], [1-4 GRADE:1], [5-9 GRADE:2], [10-12 GRADE:3], [UNIVERSITY:4])",
                "8) GUARDIAN ([MOTHER:1], [FATHER:0])",
                "9) TRAVEL TIME TO SCHOOL ([LESS THAN 15M:1], [15-30M:2], [30-60M:3], [GREATER THAN 60M:4])",
                "10) WEEKLY STUDY TIME ([LESS THAN 2H:1], [2-5H:2], [5-10H], [GREATER THAN 10H:4])",
                "11) TOTAL NUMBER OF FAILED CLASSES ([0:0], [1:1], [2:2], [3:3], [GREATER THAN 3:4])",
                "12) EXTRA EDUCATIONAL SUPPORT ([YES:1], [NO:0])",
                "13) EXTRACURRICULAR ACTIVITIES ([YES:1], [NO:0])",
                "14) ATTENDED NURSERY SCHOOL ([YES:1], [NO:0])",
                "15) WANTS HIGHER EDUCATION ([YES:1], [NO:0])",
                "16) CURRENTLY IN ROMANTIC RELATIONSHIP ([YES:1], [NO:0])",
                "17) FAMILY RELATIONSHIPS QUALITY ([VERY BAD:1], [BAD:2], [AVERAGE:3], [GOOD:4], [VERY GOOD:5])",
                "18) FREE TIME AFTER SCHOOL ([VERY LOW:1], [LOW:2], [AVERAGE:3], [HIGH:4], [VERY HIGH:5])",
                "19) TIME WITH FRIENDS ([NEVER:1], [RARELY:2], [SOMETIMES:3], [OFTEN:4], [EVERYDAY:5])",
                "20) CURRENT HEALTH STATUS ([VERY BAD: 1], [BAD:2], [AVERAGE:3], [GOOD:4], [VERY GOOD:5])",
                "21) NUMBER OF SCHOOL ABSENCES (0-93)"
        };

        String formatStr = "";
        for (int i = 0; i < 21; i++) {
            formatStr = formatStr + desc[i] + "\n\t";
        }
        tv_details.setText("The model only accepts CSV Files that have already been preprocessed. Here you can find the list of requirements for CSV Files.\n\n1. Make sure the length is divisible by 21. Our model only takes in 21 values for each test case.\n\n2. Make sure the data is formatted this way with each value separated by a comma.\n\n\t" + formatStr + "");

        Button goback = findViewById(R.id.btn_gobacktoimportCSV);
        goback.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                finish();
            }
        });
    }
}