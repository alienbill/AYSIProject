package com.example.imageclassifier;


import android.app.Activity;
import android.content.Intent;
import android.content.SharedPreferences;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.os.ParcelFileDescriptor;
import android.provider.DocumentsContract;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.RequiresApi;
import androidx.appcompat.app.AppCompatActivity;


import java.io.BufferedReader;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.util.Objects;


public class ImportCSVActivity extends AppCompatActivity {
    public static final int READ_REQUEST_CODE = 123;
    private static final int CREATE_FILE = 1;
    Uri stdUri = null;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_import_c_s_v);


        Button createCsv = findViewById(R.id.btn_createCsv);
        Button loadCsv = findViewById(R.id.btn_loadCsv);
        Button editCsv = findViewById(R.id.btn_editCsv);
        final Button submitChanges = findViewById(R.id.btn_SubmitEditedText);
        final EditText editableText = findViewById(R.id.et_editCsvFile);
        Button deleteCsv = findViewById(R.id.btn_deleteCsv);
        Button runModel = findViewById(R.id.btn_csvToModel);
        Button details = findViewById(R.id.btn_detailsForCSV);


        submitChanges.setVisibility(View.INVISIBLE);
        editableText.setVisibility(View.INVISIBLE);

        loadCsv.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                openFile();
            }
        });

        createCsv.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                createFile();
            }
        });

        editCsv.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (stdUri == null) {
                    Toast.makeText(getApplicationContext(), "No CSV file has been selected!", Toast.LENGTH_SHORT).show();
                } else {
                    submitChanges.setVisibility(View.VISIBLE);
                    editableText.setVisibility(View.VISIBLE);
                    submitChanges.setOnClickListener(new View.OnClickListener() {
                        @Override
                        public void onClick(View v) {
                            alterDocument(stdUri);
                        }
                    });
                }
            }
        });

        deleteCsv.setOnClickListener(new View.OnClickListener() {
            @RequiresApi(api = Build.VERSION_CODES.KITKAT)
            @Override
            public void onClick(View v) {
                if (stdUri == null) {
                    Toast.makeText(getApplicationContext(), "No File Selected!", Toast.LENGTH_SHORT).show();
                } else {
                    try {
                        DocumentsContract.deleteDocument(getApplicationContext().getContentResolver(), stdUri);
                        stdUri = null;
                        updateSelectedFileText();
                    } catch (FileNotFoundException e) {
                        e.printStackTrace();
                    }
                }
            }
        });

        details.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                startActivity(new Intent(ImportCSVActivity.this, detailsForCsvfile.class));
            }
        });

        runModel.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (stdUri == null) {
                    Toast.makeText(getApplicationContext(), "No File Selected!", Toast.LENGTH_SHORT).show();
                } else {

                    startActivity(new Intent(ImportCSVActivity.this, OutputCsvFile.class));
                    finish();
                }
            }
        });

    }

    @RequiresApi(api = Build.VERSION_CODES.KITKAT)
    @Override
    public void onActivityResult(int requestCode, int resultCode,
    Intent resultData) {
        super.onActivityResult(requestCode, resultCode, resultData);
        if (requestCode == READ_REQUEST_CODE
                && resultCode == Activity.RESULT_OK) {
            // The result data contains a URI for the document or directory that
            // the user selected.
            stdUri = null;
            String dataString = "";
            if (resultData != null) {
                stdUri = resultData.getData();
                try {
                    dataString = readTextFromUri(stdUri);
                } catch (IOException e) {
                    e.printStackTrace();
                }
            }

            SharedPreferences data = getSharedPreferences("AYSI",MODE_PRIVATE);
            SharedPreferences.Editor editor = data.edit();
            editor.putString("csvFileData", dataString);
            editor.commit();
            Log.d("Debug", data.getString("csvFileData","-1"));

        }
    }

    @RequiresApi(api = Build.VERSION_CODES.KITKAT)
    private String readTextFromUri(Uri uri) throws IOException {
        StringBuilder stringBuilder = new StringBuilder();
        try (InputStream inputStream = getContentResolver().openInputStream(uri);
             BufferedReader reader = new BufferedReader(new InputStreamReader(Objects.requireNonNull(inputStream)))) {
            String line;
            while ((line = reader.readLine()) != null) {
                stringBuilder.append(line);
            }
        }
        return stringBuilder.toString();
    }

    private void openFile() {
        Intent intent = new Intent(Intent.ACTION_OPEN_DOCUMENT);
        intent.addCategory(Intent.CATEGORY_OPENABLE);
        intent.setType("text/csv");
        startActivityForResult(intent, READ_REQUEST_CODE);
    }

    private void createFile() {
        Intent intent = new Intent(Intent.ACTION_CREATE_DOCUMENT);
        intent.addCategory(Intent.CATEGORY_OPENABLE);
        intent.setType("text/csv");
        intent.putExtra(Intent.EXTRA_TITLE, "data.csv");

        startActivityForResult(intent, CREATE_FILE);
    }
    private void alterDocument(Uri uri) {
        Button btn_submitChanges = findViewById(R.id.btn_SubmitEditedText);
        EditText editable = findViewById(R.id.et_editCsvFile);
        String str = editable.getText().toString();
        Log.d("debug","New Edited Text >> " + str);
        if (str.length() == 0) {
            Toast.makeText(getApplicationContext(),"No Input is detected!",Toast.LENGTH_SHORT).show();
        } else {

            editable.setVisibility(View.INVISIBLE);
            btn_submitChanges.setVisibility(View.INVISIBLE);
            try {
                ParcelFileDescriptor pfd = getApplicationContext().getContentResolver().openFileDescriptor(uri, "w");
                FileOutputStream fileOutputStream = new FileOutputStream(pfd.getFileDescriptor());
                fileOutputStream.write((str).getBytes());
                // Let the document provider know you're done by closing the stream.
                fileOutputStream.close();
                pfd.close();

                stdUri = null;
                updateSelectedFileText();

            } catch (FileNotFoundException e) {
                e.printStackTrace();
            } catch (IOException e) {
                e.printStackTrace();
            }
        }
    }

    public void updateSelectedFileText() {
        TextView selectedCsv = findViewById(R.id.tv_chosenFile);
        if (stdUri == null) {
            selectedCsv.setText("No File Selected");
        } else
            selectedCsv.setText("File: " +stdUri);
    }

    @Override
    protected void onStart() {
        super.onStart();
        updateSelectedFileText();
    }
}