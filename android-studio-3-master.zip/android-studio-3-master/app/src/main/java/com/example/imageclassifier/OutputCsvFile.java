package com.example.imageclassifier;

import androidx.annotation.RequiresApi;
import androidx.appcompat.app.AppCompatActivity;

import android.app.Activity;
import android.content.Intent;
import android.content.SharedPreferences;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.os.ParcelFileDescriptor;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.Toast;

import org.tensorflow.lite.Interpreter;

import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.util.ArrayList;

public class OutputCsvFile extends AppCompatActivity {
    public static final int READ_REQUEST_CODE = 123;
    private static final int CREATE_FILE = 1;
    private Interpreter tflite;
    private ArrayList<String> labelList;
    Uri stdUri = null;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_output_csv_file);
        Button create = findViewById(R.id.btn_createCsvOutputFile);
        Button load = findViewById(R.id.btn_loadCSVFileForOutput);
        Button output = findViewById(R.id.btn_loadOutputCSV);
        Button goback = findViewById(R.id.btn_goBackToStartFromOutputCSV);
        goback.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                finish();
            }
        });

        create.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(Intent.ACTION_CREATE_DOCUMENT);
                intent.addCategory(Intent.CATEGORY_OPENABLE);
                intent.setType("text/csv");
                intent.putExtra(Intent.EXTRA_TITLE, "data.csv");

                startActivityForResult(intent, CREATE_FILE);
            }
        });

        load.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(Intent.ACTION_OPEN_DOCUMENT);
                intent.addCategory(Intent.CATEGORY_OPENABLE);
                intent.setType("text/csv");
                startActivityForResult(intent, READ_REQUEST_CODE);
            }
        });

        output.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                SharedPreferences data = getSharedPreferences("AYSI",MODE_PRIVATE);
                String strData = data.getString("csvFileData","-1");
                Log.d("debug", strData);

                if (strData.equals("-1") || strData.equals("")) {
                    Toast.makeText(getApplicationContext(), "Error in getting data from selected CSV File. Restart Process to and try again!", Toast.LENGTH_SHORT).show();
                } else {
                    String str = runModel(strData);
                    Log.d("debug", "OutputCSV >> " + str);
                    if (str.length() == 0 || str.equals("-1")) {
                        Toast.makeText(getApplicationContext(), "Incorrect formatting of CSV. Correct Formatting can be found by clicking the details button in the previous page.", Toast.LENGTH_SHORT).show();
                    } else if (str.equals("-2")) {
                        Toast.makeText(getApplicationContext(), "Not all values in the CSV file are numbers. Check your input file again!", Toast.LENGTH_SHORT).show();
                    } else if (str.equals("-3")) {
                        Toast.makeText(getApplicationContext(), "Not all values in the CSV file are within the range. Check the formatting details again!", Toast.LENGTH_SHORT).show();
                    } else {

                        try {
                            ParcelFileDescriptor pfd = getApplicationContext().getContentResolver().openFileDescriptor(stdUri, "w");
                            FileOutputStream fileOutputStream = new FileOutputStream(pfd.getFileDescriptor());
                            fileOutputStream.write((str).getBytes());
                            // Let the document provider know you're done by closing the stream.
                            fileOutputStream.close();
                            pfd.close();

                        } catch (FileNotFoundException e) {
                            e.printStackTrace();
                        } catch (IOException e) {
                            e.printStackTrace();
                        }
                    }
                }
            }
        });
    }

    @RequiresApi(api = Build.VERSION_CODES.KITKAT)
    @Override
    public void onActivityResult(int requestCode, int resultCode,
                                 Intent resultData) {
        super.onActivityResult(requestCode, resultCode, resultData);
        if (requestCode == READ_REQUEST_CODE
                && resultCode == Activity.RESULT_OK) {
            // The result data contains a URI for the document or directory that
            // the user selected.
            stdUri = null;
            String dataString = "";
            if (resultData != null) {
                stdUri = resultData.getData();
            }
        }
    }

    public String runModel(String str) {
        String output = "";
        String[] arr = str.split(",");


        try {
            tflite = new Interpreter(Helper.loadModelFile(this.getAssets()), new Interpreter.Options());
            labelList = Helper.loadLabelList(this.getAssets());
        } catch (IOException e) {
            e.printStackTrace();
        }

        int[][] ranges =  {
                //low bound
                {
                        0,
                        15,
                        0,
                        0,
                        0,
                        0,
                        0,
                        0,
                        1,
                        1,
                        0,
                        0,
                        0,
                        0,
                        0,
                        0,
                        1,
                        1,
                        1,
                        1,
                        0
                },
                //high bound
                {
                        1,
                        22,
                        1,
                        1,
                        1,
                        4,
                        4,
                        1,
                        4,
                        4,
                        4,
                        1,
                        1,
                        1,
                        1,
                        1,
                        5,
                        5,
                        5,
                        5,
                        93
                }
        };


        if (arr.length % 21 != 0) {
            return "-1";
        } else {
            for (int x =0; x < arr.length/21; x++) {
                float[] row = new float[21];
                for (int y = 0; y < 21; y++) {
                    if (!isNumber(arr[y+ (x*21)])) {
                        return "-2";
                    }
                    row[y] = (float) Integer.parseInt(arr[y + (x * 21)]);
                    if (row[y] > ranges[1][y] || row[y] < ranges[0][y])
                        return "-3";
                }
                float[][] label = new float[1][6];
                tflite.run(row, label);
                int val = 0;
                for (int z = 0; z < 6; z++) {
                    if (Math.round(label[0][z]) == 1) {
                        val = z;
                    }
                    Log.d("debug", "" + label[0][z]);
                }
                output = output + val + " ";
            }
            return output;
        }
    }
    public boolean isNumber(String str) {
        if (str.length() == 0)
            return false;
        char[] arr = str.toCharArray();
        for (int x =0; x < arr.length; x++) {
            if (arr[x] < 48 || arr[x] > 57) {
                return false;
            }
        }
        return true;
    }

}