
package com.example.imageclassifier;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;

public class MainActivity extends AppCompatActivity {
    private Button takeQuestionaire;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        Button gotoImport = findViewById(R.id.btn_gotoImport);
        SharedPreferences data = getSharedPreferences("AYSI",MODE_PRIVATE);
        SharedPreferences.Editor editor = data.edit();
        editor.clear();
        editor.commit();
        gotoImport.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                startActivity(new Intent(MainActivity.this, ImportCSVActivity.class));
            }
        });

        takeQuestionaire = (Button) findViewById(R.id.btn_goToQuestionaire);
        takeQuestionaire.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                startActivity(new Intent(MainActivity.this, Questionaire.class));
            }
        });

        TextView description = (TextView) findViewById(R.id.tv_description);
        description.setText("This app is designed to both increase self-awareness about alcohol risk and provide a tool for others to be informed and help an individual engaged in alcohol consumption.");

    }
}